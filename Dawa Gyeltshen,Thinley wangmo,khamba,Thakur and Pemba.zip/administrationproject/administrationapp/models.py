from django.db import models
GENDER=[
('Male','Male'),
('Femail','Femail'),
('Other', 'Other')
]

# Create your models here.
class Forms(models.Model):
	
	Name=models.CharField(max_length=50)
	DOB=models.CharField(max_length=50)
	Gender=models.CharField(max_length=50)
	Age=models.IntegerField()
	Contact=models.IntegerField(unique=True,)
	Email=models.CharField(unique=True,max_length=50)
	Suggestion=models.CharField(max_length=1000)


	class Meta:
		verbose_name="Forms"
		verbose_name_plural="Formss"

	def __str__(self):
		return self.name

# Create your models here.
class EmployeeDetails(models.Model):
    slno= models.CharField(unique=True,max_length=50)
    name = models.CharField(max_length=50)
    gender = models.CharField(choices=GENDER, max_length=50)
    department = models.CharField( max_length=50)
    contact = models.IntegerField()

    class Meta:
        verbose_name='EmployeeDetails'
        verbose_name_plural='EmployeeDetailss'
    def str(self):
        return self.slno


	
