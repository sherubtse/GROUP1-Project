
from django.shortcuts import render
from administrationapp.models import Forms,EmployeeDetails

# Create your views here.
def Forms_One(request):
	if request.method=="GET":
		return render(request,'administrationapp/register.html')


	if request.method=="POST":
		data=request.POST.dict()

		data=Forms.objects.create(Name=data['Name'],DOB=data['DOB'],Gender=data['Gender'],Age=data['Age'],Contact=data['Contact'],Email=data['Email'],Suggestion=data['Suggestion'])
		data.save()

	return render(request,'administrationapp/success.html',context={"data":data})

def register(request):
	if request.method=="GET":
		return render(request,'administrationapp/register.html')


	if request.method=="POST":
		data=request.POST.dict()

		data=Forms.objects.create(Name=data['Name'],DOB=data['DOB'],Gender=data['Gender'],Age=data['Age'],Contact=data['Contact'],Email=data['Email'],Suggestion=data['Suggestion'])
		data.save()

	return render(request,'administrationapp/success.html',context={"data":data})


def home(request):
	return render(request,'administrationapp/home.html')

def campus(request):
	return render(request,'administrationapp/campus.html')


# Create your views here.
def contact(request):
	data=EmployeeDetails.objects.all()
	return render(request,"administrationapp/contact staffs.html", context={"data":data})



def mission(request):
	return render(request,'administrationapp/mission.html')

def resources(request):
	return render(request,'administrationapp/resources.html')

def staff(request):
	return render(request,'administrationapp/staff.html')

def stategies(request):
	return render(request,'administrationapp/strategic plan.html')






